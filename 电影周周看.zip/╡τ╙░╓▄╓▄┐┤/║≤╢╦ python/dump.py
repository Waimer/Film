# encoding: UTF-8
import io
import sys
from bs4 import BeautifulSoup
import requests
import time
import json
import MySQLdb
import unicodedata
import binascii
reload(sys)
sys.setdefaultencoding('utf8')
#sys.stdout = io.TextIOWrapper(sys.stdout.buffer,encoding='gb18030')
db = MySQLdb.connect("git.8buff.com","root","TrevorPhillips","douban",charset="utf8")
cursor = db.cursor()
url = 'https://movie.douban.com/j/search_subjects?type=movie&tag=%E5%96%9C%E5%89%A7&sort=recommend&page_limit=20&page_start=80'
header = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36","Referer": "https://movie.douban.com/explore","X-Requested-With": "XMLHttpRequest","DNT": "1","Accept": "*/*"}
cookie= 'viewed="26611545"; bid=Gf5St8AtLpk; __utmc=30149280; ll="108288"; __utmc=223695111; _vwo_uuid_v2=D6301AF89DD3F8186F9A7609228509A81|6a5580824d24a9e4eea446961ac0475c; push_noty_num=0; push_doumail_num=0; __utmv=30149280.19892; douban-profile-remind=1; ps=y; __utmz=30149280.1562064767.7.4.utmcsr=movie.douban.com|utmccn=(referral)|utmcmd=referral|utmcct=/; __utmz=223695111.1562064772.6.3.utmcsr=douban.com|utmccn=(referral)|utmcmd=referral|utmcct=/misc/sorry; dbcl2="198923225:cjqg8ENDoKs"; ck=Aq2x; _pk_ref.100001.4cf6=%5B%22%22%2C%22%22%2C1562080090%2C%22https%3A%2F%2Fwww.douban.com%2Fmisc%2Fsorry%3Foriginal-url%3Dhttps%253A%252F%252Fmovie.douban.com%252Fexplore%22%5D; _pk_id.100001.4cf6=9f46a2750b8f545a.1562036365.10.1562080090.1562076240.; __utma=30149280.1350215003.1561639115.1562075063.1562080091.10; __utma=223695111.244421394.1562036365.1562075063.1562080091.10; __utmb=223695111.0.10.1562080091; __utmb=30149280.3.9.1562080478161'
header["Cookie"]=cookie  //加密后的用户名
header2= {"x-xyst": "KjdPVD9HZVt3d2E3IGNZOmdkUm5PNCHqzHLAk7yCDge8fVSd2_SD1A==","DNT": "1"}
header2["Cookie"]=cookie
header['x-xyst']="fGo2bX5be34uLW1daDA1JZVMctUSm5OUQSLFJc0lU8ZgYTDZDowhsg=="
header2['x-xyst']="fGo2bX5be34uLW1daDA1JZVMctUSm5OUQSLFJc0lU8ZgYTDZDowhsg=="
header2['User-Agent']="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36"
header2['Host']="movie.douban.com"
header2['Accept-Language']="zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7"
header2['Accept-Encoding']="gzip, deflate, br"
#wb_data = requests.get(url)
#soup = BeautifulSoup(wb_data.text,'lxml')

#URL

def get_new_links(page_start):
    urls = []
    list_view = "https://movie.douban.com/j/new_search_subjects?sort=U&range=0,20&tags=&genres=%E5%8A%A8%E4%BD%9C&start={}".format(str(page_start))
    wb_data = requests.get(list_view,headers=header2)
    text = json.loads(wb_data.text)
    #print text['subjects'][0]
    subjects=text['data']
    itemurl = []
    for subject in subjects:
        itemurl.append(subject['url'])
        get_item_info(subject['url'],subject['rate'],subject['title'])

def get_links_from(page_start):
    urls = []
    list_view = 'https://movie.douban.com/j/search_subjects?type=movie&tag=%E7%88%B1%E6%83%85&sort=recommend&page_limit=20&page_start={}'.format(str(page_start))
    #print ('list_view:{}'.format(list_view) )
    wb_data = requests.get(list_view,headers=header)
    text = json.loads(wb_data.text)
    #print text['subjects'][0]
    subjects=text['subjects']
    itemurl = []
    for subject in subjects:
        itemurl.append(subject['url'])
    get_item_infos(itemurl)
'''
    soup = BeautifulSoup(wb_data.text,'lxml')
    #for link in soup.select('td.t > a.t'):
    for link in soup.select('td.t  a.t'):  #
        print link
        urls.append(link.get('href').split('?')[0])
    return urls
'''


#
def get_item_info(url,rate,title):
    wb_data = requests.get(url,headers=header)
    wb_data.encoding="utf8"
    soup = BeautifulSoup(wb_data.text,'lxml')
    abstract=""
    try:
        abstract = soup.select('div[id="link-report"] > span')[0].text
    except:
        print(url)
    review =  soup.select('span[class="short"]')[1].text
    if(title==""):
        title = soup.select('div[id="content"] > h//分类标诀1 > span')[0].text
    #rate = soup.select('div[class="rating_self clearfix"] strong')[0].text
    pic = soup.select('a[class="nbgnbg"] img')[0].get("src")
    review = review.replace("\n","").replace("\"","").replace("\'","")
    if(rate ==""):
        rate = soup.select('div[class="rating_self clearfix"] strong')[0].text
    if(rate==""):
        rate=-1
    sqlins = "insert into films (title,rate,abstract,review,pic,category) VALUES('%s',%f,'%s','%s','%s','%s')" % (title,float(rate),abstract.replace(" ","").replace("\n","").replace("\"","").replace("\'",""),review,pic,9)
    try:
        cursor.execute(sqlins)
        db.commit()
    except Exception as e:
        if e[0] == 1064:
            print(e)
            #print(sqlins.encode("utf8"))
        elif e[0] == 1062:
            print("dup"),
        else:
            print(e)
        db.rollback()
//分类标识ID:cate
def get_item_infos(urls):
     for url in urls:
        #print url
        wb_data = requests.get(url,headers=header)
        wb_data.encoding="utf8"
        soup = BeautifulSoup(wb_data.text,'lxml')
#        print(soup.text.decode('utf-8'))
        #print soup.select('infolist > div > table > tbody > tr.article-info > td.t > span.pricebiao > span')
##infolist > div > table > tbody > tr.article-info > td.t > span.pricebiao > span
        abstract = soup.select('div[id="link-report"] > span')[0].text
        review =  soup.select('span[class="short"]')[1].text
        title = soup.select('div[id="content"] > h1 > span')[0].text
        rate = soup.select('div[class="rating_self clearfix"] strong')[0].text
        pic = soup.select('a[class="nbgnbg"] img')[0].get("src")
        #print(type(review))
        #print(soup.select('span[class="short"]')[0].encode("utf8").encode("hex"))
        #print(review.decode("utf8").encode("utf8"))
        review = review.replace("\n","").replace("\"","").replace("\'","")
        #print(review.decode('utf-8','ignore').encode("hex"))
        #review = review.encode("utf8").encode("hex")
        #print(review)
        #print pic
        sqlins = "insert into films (title,rate,abstract,review,pic,category) VALUES('%s',%f,'%s','%s','%s','%s')" % (title,float(rate),abstract.replace(" ","").replace("\n","").replace("\"","").replace("\'",""),review,pic,15)
        #print sqlins
        try:
            cursor.execute(sqlins)
            db.commit()
        except Exception as e:
            if e[0] == 1064:
                print(e)
                #print(sqlins.encode("utf8"))
            elif e[0] == 1062:
                print("dup"),
            else:
                print(e)
            db.rollback()
        #print("title:")
        #print title
        #print "rate"+rate
        #print soup.select('div[class="palce_li"]')[0].text
        #print list(soup.select('.palce_li')[0].stripped_strings) if soup.find_all('div','palce_li') else None,
#body > div > div > div > div > div.info_massege.left > div.palce_li > span > i
'''
        data = {
            'title':soup.title.text,
            'price': soup.select('span[class="price_now"]')[0].text,
            'area': soup.select('div[class="palce_li"]')[0].text if soup.find_all('div', 'palce_li') else None,
            'date' :soup.select('.look_time')[0].text,
            'cate' :'' if who_sells == 0 else '',
        }
        print(data)
        result = json.dumps(data, encoding='UTF-8', ensure_ascii=False) # json
        print result
'''

# get_item_info(url)
#start_id = 353
start_id = 160
while start_id<600:
    print("start_id:")
    print(start_id)
    #get_links_from(start_id)
    get_new_links(start_id)
    start_id+=20

#get_item_info(2)
#get_classify_url()
