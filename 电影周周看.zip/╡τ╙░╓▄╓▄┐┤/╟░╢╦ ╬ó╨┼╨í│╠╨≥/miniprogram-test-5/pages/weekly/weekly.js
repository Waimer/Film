// pages/weekly/weekly.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentWeek:12,
    movieList:[
      {
        name:"疯狂的外星人",
        comment:"宁浩的黑色荒诞",
        imagePath:"/images/icons/waixingren.jpg",
        id:12
      },
      {
        name: "毒液",
        comment: "漫威中唯一的反派英雄。",
        imagePath: "/images/icons/dy.jpg",
        id:11
      },
      {
        name: "飞驰人生",
        comment: "我不想索然无味的过完这一生",
        imagePath: "/images/icons/fcrs.jpg",
        id:10
      }
    ],
    pastList:[
      {
        name:"调音师",
        id:9
      },
      {
        name:"流浪地球",
        id:8
      },
      {
        name:"大侦探皮卡丘",
        id:7
      },
      {
        name: "雪暴",
        id:6
      },
      {
        name: "地久天长",
        id:5
      },
      {
        name: "恶人传",
        id: 4
      },
      {
        name: "小委托人",
        id: 3
      },
      {
        name: "绿皮书",
        id: 2
      },
      {
        name: "孟买酒店",
        id: 1
      }
    ]
  },
  f1:function(event){
    var movieId = event.currentTarget.dataset.movieId
    console.log(movieId);

    wx.navigateTo({
      url:'/pages/detail/detail?id=' + movieId
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})