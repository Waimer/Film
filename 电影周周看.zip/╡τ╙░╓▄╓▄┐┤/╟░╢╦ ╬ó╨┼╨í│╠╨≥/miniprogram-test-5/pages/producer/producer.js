Page({
  data: {
    getInput: null,
    inputInit: '',
  },
  onload:function(){
    wx.cloud.downloadFile({
      fileID: 'cloud://little-program-mmzgr.6c69-little-program-mmzgr-1259553339/微信背景.png', // 文件 ID
      success: res => {
        // 返回临时文件路径
        filepath=res.tempFilePath
      },
      fail: console.error
    })
  },
  getInput: function (e) {
    this.data.getInput = e.detail.value;
    //console.log(this.data.getInput);
  },
  collectionAdd:function(){
    if(this.data.getInput!=null){
      const db=wx.cloud.database();
      db.collection('film').add({
        data:{
          comment:this.data.getInput,
          due:new Date,
        },
        success : res=>{
        },
      });
      this.setData({
        inputInit: '', // 清空输入框中的内容
      });
      wx.showToast({
        title: '提交成功',
        icon: 'success',
        duration: 2000
        })
    }else{
      wx.showToast({
        title: '请输入内容',
        icon: 'none',
        duration: 2000
      })
    }
  }
})