
Page({
  data: {
    movietype:[
      {
        name:"喜剧",
        inmgePath:"/images/Comedy.png",
        id:1,
      },
            {
        name: "爱情",
        inmgePath: "/images/love.png",
        id: 2,
      },
            {
        name: "动画",
              inmgePath: "/images/Children.png",
        id: 3,
      },
            {
        name: "科幻",
              inmgePath: "/images/kehuan.png",
        id: 4,
      },
            {
        name: "动作",
              inmgePath: "/images/action.png",
        id: 5,
      },
            {
        name: "悬疑",
        inmgePath: "/images/xuanyi.png",
        id: 6,
      },
    ]
  },
  f1:function(event){
    var movieId = event.currentTarget.dataset.movieId
    console.log(movieId);

    wx.navigateTo({
      url: '/pages/movie/movie?id='+movieId,
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

})