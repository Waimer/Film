Page({

  data: {
    mid:-1,
    datalist: []
  },

  onLoad: function(options) {
    var that = this;
    console.log(options.id)
    this.setData({
      mid: options.id
    });
    wx.request({
      url: "https://git.8buff.com:3000/?cate=" + that.data.mid,
      success: function(res) {
        console.log(res.data)
        that.setData({
          datalist: res.data,
        })
      }

    })
  },
  f1: function (event) {
    var movieId = event.currentTarget.dataset.movieId
    console.log(movieId);

    wx.navigateTo({
      url: '/pages/detail/detail?id=' + movieId
    })
  },
})