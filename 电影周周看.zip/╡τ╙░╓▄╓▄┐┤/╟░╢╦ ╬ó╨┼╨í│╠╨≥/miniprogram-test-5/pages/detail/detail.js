
Page({
  data:{
    mid:-1,
    title:[],
    description:"",
    rate:0,
    review:"",
    pic:"",
    
  },
  onLoad:function (options){
    var that=this;
    console.log(options.id)
    this.setData({
      mid:options.id
    });
    //
    wx.request({
      url: "https://git.8buff.com:3000/?id=" + that.data.mid,
      success: function(res){
        console.log(res.data)
        that.setData({
          title:res.data['title'],
          rate:res.data['rate'],
          description:res.data['abstract'],
          review: res.data['review'],
          pic: res.data['pic'],
        })
      },
      fail: function(res){
        console.log(res)
      }
    })
    
  }
})
